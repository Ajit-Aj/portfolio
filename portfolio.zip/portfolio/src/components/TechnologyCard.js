// // TechnologyCard.js
// import React from "react";
// import "./TechnologyStyles.css"
// const TechnologyCard = ({ technology, imageSrc }) => {
//   return (
//     <div className="technology-card">
//       <img src={imageSrc} alt={technology} />
//       <h3>{technology}</h3>
//     </div>
//   );
// };

// export default TechnologyCard;
import React from 'react'

function TechnologyCard() {
  return (
    <div>TechnologyCard</div>
  )
}

export default TechnologyCard
